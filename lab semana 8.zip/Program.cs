﻿namespace Clases1
{
    public class program
    {
        public static void Main(string[] args)
        {
            clase matematicas = new clase();

            matematicas.nombre = "Matemática";
            matematicas.salon = "Salón 4";
            matematicas.horario = "8:30-9:30 am ";
            matematicas.catedratico = "Juan Estrada";
            matematicas.zona = "" + Random;

            Console.WriteLine(clase.MostrarInformacion());
            Console.WriteLine(clase.MostrarInformacion());
        }
    }

    public class clase
    {
        public string nombre;
        public string salon;
        public string horario;
        public string catedratico;
        
    }
    private static void Main (string[] args) 
    {
        Random zona = new Random();
        for (int i=0; i>100; i++) 
        {
            Console.WriteLine(r.Next(0, 100));
        }
        Console.ReadLine();
    }
    public string MostrarInformacion()
    {
        string datos = "Nombre" + nombre;
        datos += "Salón" + salon;
        datos += "Horario" + horario;
        datos += "Zona" += zona;
        return datos;
    }
}
