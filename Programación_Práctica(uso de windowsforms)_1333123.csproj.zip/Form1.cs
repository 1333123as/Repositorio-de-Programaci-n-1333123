using System.Globalization;
using WinFormsApp;

namespace Programación_Práctica_uso_de_windowsforms__1333123
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        public void textBox1_TextChanged(object sender, EventArgs e)
        {
     
        }
    }
}
namespace WinFormsApp
{
    public class OperacionesSumatoria
    {
        public OperacionesSumatoria()
        {

            Console.WriteLine("Indique hasta donde desea su sumatoria: ");
            int valor = int.Parse(Console.ReadLine());
            for (int i = 1; i <= valor; i++)
            {

            }
        }

    }
}

namespace WinFormsApp
{
    public class OperacionesFactorial
    {
        public OperacionesFactorial()
        {
            Console.WriteLine("Indique su valor factorial: ");
            int valor1 = int.Parse(Console.ReadLine());
            for (int i = 1; i <= valor1; i++)
            {
                i *= valor1;

            }
        }

    }
}

namespace WinFormsApp
{
    public class OperacionesNP
    {
        public OperacionesNP()
        {
            Console.WriteLine("Indique su valor factorial: ");
            int a, b, c;

            for (int i = 2; i <= 500; i++)
            {
                a = 0;
                b = i / 2;
                
                for (int j =1; i<=b; j++)
                {
                    c = i % j;

                    if (c == 0)
                    {
                        a = a + j;
                    }
                    if (a==i)
                        Console.WriteLine("El número es perfecto: " + i);
                }


            }
        }

    }
}

namespace WinFormsApp
{
    public class OperacionesTM
    {
        public OperacionesTM()
        {
            int numero;
            string linea;
            Console.Write("Ingrese multiplicador: ");
            linea = Console.ReadLine();
            numero = int.Parse(linea);
            for (int i = 1; i <= 15; i++)
            {
                Console.Write(i + " x " + numero + " = " + i * numero + "\n");
            }

        }
    }
}