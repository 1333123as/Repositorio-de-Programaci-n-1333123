﻿namespace Lab1;

public class Program
{
    public static void Main(string[] args)
    {
        Animal perro = new Animal();
        perro.nombre = "Canis lupus familiaris";
        perro.EstaExtinto = false;
        perro.AniosPromedio = 10.5;
        perro.Reino = "Animal";
        Console.WriteLine(perro.MostrarInformacion());

        Animal aveztruz = new Animal();
        Console.WriteLine(aveztruz.MostrarInformacion());
    }
}


namespace Lab1
{
    public class Animal
    {
        public string nombre;
        public bool EstaExtinto;
        public double AniosPromedio;
        public string Reino;
        public bool EsMamifero, EsTerrestre;
        public int NumOjos;
        public int NumPata;
        public bool TienePelo;
        public bool Vuela;
    }

    public string MostrarInformacion()
    {
        string datos = "Nombre: " + nombre;
        datos += "Esta extinto: " + EstaExtinto;
    }

    public void Dormir()
    {
    }
    public void Comer()
    {
    }
}
