﻿//llamar a consola
using System;

Console.WriteLine("Cuantos dias desea registrar?");
int dias = int.Parse(Console.ReadLine());

//arreglo
double[] temperaturaDias = new double[dias];

for (int i = 0; i < temperaturaDias.Length; i++)
{
    Console.WriteLine("Ingrese la temperatura del día" + (i + 1) + ": ");
    double dato = double.Parse(Console.ReadLine());
    temperaturaDias[i] = dato;
}

//Mostrar todos los datos ingresados
//temperatura mayor
for (int i = 0; i < temperaturaDias.Length; i++)
{
    Console.WriteLine("Dia" + (i + 1) + ": " + temperaturaDias[i] + "C");
}
double mayor = temperaturaDias[0];
int diaMayor = 0;
for (int i = 0; i < temperaturaDias.Length; i++)
{
    if (temperaturaDias[i] > mayor)
    {
        mayor = temperaturaDias[i];
        diaMayor = i;
    }
}
Console.WriteLine("El dia con mayor temperatura fue: " + diaMayor + " con " + mayor);

//temperatura menor

double menor = temperaturaDias[0];
int diaMenor = 0;
for (int i = 0; i < temperaturaDias.Length; i++)
{
    if (temperaturaDias[i] < menor)
    {
        menor = temperaturaDias[i];
        diaMenor = i;
    }
}
Console.WriteLine("El dia con menor temperatura fue: " + diaMenor + " con " + menor);



//Promedio de todas las temperaturas
double sumaDeTemperaturas = 0;
for (int i = 0; i < temperaturaDias.Length; i++)
{ 
    sumaDeTemperaturas += temperaturaDias[i];
}
double promedioDeTemperatura = sumaDeTemperaturas / temperaturaDias.Length;
Console.WriteLine("El promedio es: " + promedioDeTemperatura + "C");

//temperatura en F
    Console.WriteLine("El dia con menor temperatura fue: " + ((menor * 1.8) + 32) + "F");
    Console.WriteLine("El dia con mayor temperatura fue: " + ((mayor * 1.8) + 32) + "F");
    double temperaturaenF = (((sumaDeTemperaturas * 1.8) + 32));
    Console.WriteLine("La temperatura promedio en F es: " + temperaturaenF + "F");




