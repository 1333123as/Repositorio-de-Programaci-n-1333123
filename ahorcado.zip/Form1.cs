using System.Drawing.Text;
using System.Security.Cryptography.X509Certificates;

namespace _1333123_app
{
    public partial class Form1 : Form
    {
        string palabra = "COPA";
        int letter;
        bool usamuestra;
        int mal;
        int bien;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string _palabra = "";
            char[] _palabraCharts;

            _palabra = textBox1.Text;
            _palabraCharts = _palabra.ToArray();

            for (int i = 0; i< _palabraCharts.Length; i++)
            {
                MessageBox.Show("Caracter es: " + _palabraCharts[i]);
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (txtLetras.Text != "")
            {
                int vacant = 0;
                if (txtTodas.Text == "")
                    txtTodas.Text = txtLetras.Text;
                else
                    txtTodas.Text = txtLetras.Text + " , " + txtLetras.Text;

                do
                {
                    if (vacant == 0)
                        letter = palabra.IndexOf(txtLetras.Text);
                    else
                        letter = palabra.IndexOf(txtLetras.Text, letter + 1);
                    usamuestra = MostrarLetras(letter);
                    if (bien == palabra.Length)
                    {
                        MessageBox.Show("Respuesta correcta :)");
                        limpiar();
                        txtLetras.Focus();
                    }
                    if (usamuestra)
                    {
                        vacant += 1;
                    }
                }
                while (usamuestra);
                if (vacant == 0)
                {
                    mal += 1;
                    MessageBox.Show("Perdiste!!");
                }
            }
            txtLetras.Text = "";
            txtLetras.Focus();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ubiLetras(palabra);
        }
        public void ubiLetras(String palabra)
        {
            int longitud = palabra.Length;
            for (int i=0; i < longitud; i++)
            {
                switch(i)
                {
                    case 0: 
                        label5.Visible = true;
                        label5.Text = palabra.Substring(i,1);
                        break;
                    case 1:
                        label6.Visible = true;
                        label6.Text = palabra.Substring(i, 1);
                        break;
                    case 2: label7.Visible = true;
                        label7.Text = palabra.Substring(i, 1);
                        break;
                    case 3: label8.Visible = true;
                        label8.Text = palabra.Substring(i, 1);
                        break;
                }
            }

        }
        public bool MostrarLetras(int letter)
        {
            bool result = true;
            bien += 1;
            switch(letter)
            {
                case 0:
                    label5.Visible = true;
                    
                    break;
                case 1:
                    label6.Visible = true;
                    
                    break;
                case 2:
                    label7.Visible = true;
        
                    break;
                case 3:
                    label8.Visible = true;
                   
                    break;
            }
        }
        public void limpiar()
        {
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            mal = 0;
            bien = 0;
            txtTodas.Text = "";
        }
    }
}

