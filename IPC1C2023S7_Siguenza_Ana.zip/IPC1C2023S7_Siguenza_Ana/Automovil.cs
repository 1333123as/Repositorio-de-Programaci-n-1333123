﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPC1C2023S7_Siguenza_Ana
{
    internal class Automovil
    {
        private int modelo = 2019;
        private double precio = 10000.00;
        private string marca;
        private bool disponible = false;
        private double tipocambiodolar = 7.5;
        private double descuentoaplicado = 0;

    }
}
//Me perdí en el paso tres :(