﻿namespace Menu
{
    public class Programa
    {
        public static void Main(string[] args)
        {
            // Inicio de Progrma
            MostrarMenuPrincipal();
        }

        public static void MostrarMenuPrincipal()
        {
            int opcion = 0;
            int cantidad = 0;

            do
            {
                Console.Clear();
                Console.WriteLine("Menú de opciones: ");
                Console.WriteLine("-----------------");
                Console.WriteLine("\n 1. Premium" + "\n 2. Super" + "\n 3. Diesel" + "\n 4. Regular" + "\n 5. Salir");
                Console.WriteLine("-----------------");
                Console.WriteLine("Coloque que opción desea: ");
                opcion = Convert.ToInt32(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        Console.WriteLine("Cuantos quetzales desea de gasolina: ");
                        cantidad = int.Parse(Console.ReadLine());
                        break;
                    case 2:
                        Console.WriteLine("Cuantos quetzales desea de gasolina: ");
                        cantidad = int.Parse(Console.ReadLine());
                        break;
                    case 3:
                        Console.WriteLine("Cuantos quetzales desea de gasolina: ");
                        cantidad = int.Parse(Console.ReadLine());
                        break;
                    case 4:
                        Console.WriteLine("Cuantos quetzales desea de gasolina: ");
                        cantidad = int.Parse(Console.ReadLine());
                        break;
                    case 5:
                        Console.WriteLine("Cuantos quetzales desea de gasolina: ");
                        cantidad = int.Parse(Console.ReadLine());
                        break;
                    default:
                        Console.WriteLine("Opción no valida");
                        break;
                }
            }
            while (opcion != 5);
        }
    }
}








