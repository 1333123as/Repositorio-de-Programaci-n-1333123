﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_de_gasolinera_Jessell_Ana
{
    public class Bombas
    {
       public string[] nombre = new string[] { "Bomba 1", "Bomba 2", "Bomba 3", "Bomba 4", "Bomba 5" };
    }
}
