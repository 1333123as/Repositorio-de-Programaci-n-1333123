﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herencia_1333123
{
    public class Productos
    {
        private Guid Id;
        public string nombre;
        public decimal cantidad;
        public decimal costo;
        public string unidad;
    }
}

