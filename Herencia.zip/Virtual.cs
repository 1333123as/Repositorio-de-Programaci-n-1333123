﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herencia_1333123
{
    public class Virtual : Productos
    {
        public bool EsCanjeable;
    }
}

