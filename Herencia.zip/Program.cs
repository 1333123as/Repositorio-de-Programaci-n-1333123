﻿using System.Net.Http.Headers;

namespace Herencia_1333123
{
    public class Program
    {
        static void Main(string[] args)
        {
            Productos product = new Productos();
            product.nombre = "Producto genérico";
            product.cantidad = 340;
            product.unidad = "cantidad de unidades";
            product.costo = 160;

            Perecedero food = new Perecedero();
            food.FechaCaducidad = new DateTime(2023, 04, 16);
            food.FechaProduccion = new DateTime(2023, 03, 02);
            food.nombre = "Producto genérico";
            food.cantidad = 340;
            food.unidad = "Unidades";
            food.costo = 56;
            food.lote = 3.23;

            if (food is Productos)
            {
                Console.WriteLine("Es producto");
            }
            else
            {
                Console.WriteLine("No es producto");
            }
            Console.ReadLine();

            NoPerecedero tool = new NoPerecedero();
            tool.nombre = "Producto genérico";
            tool.cantidad = 200;
            tool.unidad = "Unidades";
            tool.costo = 65;
            tool.lote = 2.0;

            Natural onions = new Natural();
            onions.nombre = "Producto genérico";
            onions.cantidad = 23;
            onions.unidad = "Unidades";
            onions.costo = 3;
            onions.lote = 4.0;
            onions.FechaCaducidad = new DateTime(2023, 09, 16);
            onions.FechaProduccion = new DateTime(2023, 02, 11);
            onions.Precocido = false;

            if (onions is Natural)
                Console.WriteLine("Papa es ");

            if (onions is Perecedero)
                Console.WriteLine("Papa es ");

            Virtual virtu = new Virtual();
            virtu.EsCanjeable = true;
        }
    }
}


