﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herencia_1333123
{
    public class Perecedero : Productos
    {
        public DateTime FechaProduccion;
        public DateTime FechaCaducidad;
        public double lote;
    }
}

